# Voya MVP 🌴

App para planear viajes con AI: descubre actividades, organízalas en un calendario y obtén un presupuesto realista.

**Stack:** Next.js 14 · TypeScript · Tailwind · Supabase Auth + DB · Claude AI

---

## Estado actual del proyecto

✅ **Bloque 1 (este):** Setup base + autenticación
- Setup completo del proyecto
- Database schema con 4 tablas y Row Level Security
- Sistema de auth con email + password
- Páginas: landing, signup, login
- Dashboard placeholder
- Middleware para proteger rutas

⏳ **Bloque 2 (próximo):** Dashboard + creación de viajes

⏳ **Bloque 3:** Integración Claude AI + actividades

⏳ **Bloque 4:** Calendario + presupuesto + export ICS

⏳ **Bloque 5:** Pulido final + deploy

---

## 🚀 Setup paso a paso

### 1. Instala dependencias

```bash
cd voya-mvp
npm install
```

### 2. Configura Supabase

1. Ve a tu proyecto de Supabase → **SQL Editor** → **New query**
2. Copia y pega el contenido de `supabase/schema.sql`
3. Click en **Run**
4. Verifica que se crearon 4 tablas: `profiles`, `trips`, `activities`, `schedule`

### 3. Obtén las credenciales de Supabase

En Supabase → **Project Settings** → **API**:

- Copia el **Project URL**
- Copia la **anon public** key (NO la service_role esta vez)

⚠️ **Diferencia importante:** En este MVP usamos la **anon key** (pública, segura para el frontend) en vez de la service_role. Esto es porque ahora tenemos Row Level Security activado, así que cada query se filtra automáticamente por usuario.

### 4. Crea `.env.local`

```bash
cp .env.example .env.local
```

Edita y pega tus valores:

```env
NEXT_PUBLIC_SUPABASE_URL=https://tuproyecto.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGc...
ANTHROPIC_API_KEY=sk-ant-... # opcional aún, lo usaremos en el bloque 3
```

### 5. Configura Supabase Auth

En tu dashboard de Supabase:

1. Ve a **Authentication** → **Providers**
2. Asegúrate que **Email** esté habilitado
3. Ve a **Authentication** → **Email Templates** (opcional, para personalizar emails)
4. Ve a **Authentication** → **URL Configuration**:
   - **Site URL:** `http://localhost:3000` (luego lo cambias a tu URL de Vercel)
   - **Redirect URLs:** agrega `http://localhost:3000/**` y tu URL de Vercel

### 6. (Opcional) Desactiva confirmación de email para desarrollo

Para que los signups funcionen sin tener que verificar emails:

1. **Authentication** → **Providers** → **Email**
2. Desactiva **"Confirm email"**
3. Guarda

⚠️ Para producción, vuelve a activarlo (más seguro).

### 7. Corre el proyecto

```bash
npm run dev
```

Abre [http://localhost:3000](http://localhost:3000).

---

## ✅ Cómo verificar que todo funciona

1. ✅ Abre `http://localhost:3000` → ves la landing
2. ✅ Click en **"Empezar gratis"** → te lleva a `/auth/signup`
3. ✅ Crea una cuenta con un email cualquiera
4. ✅ Te redirige automáticamente a `/dashboard`
5. ✅ Verifica en Supabase: **Authentication → Users** debe aparecer tu nuevo usuario
6. ✅ Verifica en Supabase: **Table Editor → profiles** debe aparecer tu perfil
7. ✅ Click en **"Cerrar sesión"** → vuelves a la landing
8. ✅ Click en **"Iniciar sesión"** con las mismas credenciales → vuelves al dashboard

Si todo lo anterior funciona, **el bloque 1 está listo**. ✨

---

## 📁 Estructura del proyecto

```
voya-mvp/
├── app/
│   ├── auth/
│   │   ├── actions.ts          # Server actions: signup, login, logout
│   │   ├── login/page.tsx      # Página de login
│   │   └── signup/page.tsx     # Página de signup
│   ├── dashboard/page.tsx      # Dashboard (bloque 2)
│   ├── globals.css
│   ├── layout.tsx
│   └── page.tsx                # Landing
├── components/                  # (bloque 2-5)
├── lib/
│   └── supabase/
│       ├── client.ts           # Cliente browser
│       ├── server.ts           # Cliente server
│       └── middleware.ts       # Refresh de sesiones
├── supabase/
│   └── schema.sql              # Schema completo de la DB
├── types/
│   └── index.ts                # Tipos compartidos
├── middleware.ts               # Protege rutas /dashboard, /trip
├── .env.example
└── package.json
```

---

## 🐛 Troubleshooting

**Error: "Auth session missing"**
→ Cookies de Supabase no se están seteando bien. Reinicia el servidor.

**Error: "Email not confirmed"**
→ Desactiva la confirmación de email en Supabase (paso 6 del setup).

**Signup funciona pero el profile no se crea**
→ Verifica que el trigger `on_auth_user_created` se creó. Vuelve a correr el `schema.sql`.

**Redirect loops en /dashboard**
→ Verifica que el middleware esté funcionando. Limpia cookies del navegador.

---

## ⏭️ Siguientes pasos

Cuando hayas verificado los 8 puntos del checklist, avísame y pasamos al **Bloque 2**: dashboard funcional con creación de viajes.
