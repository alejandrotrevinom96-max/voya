import { createClient } from "@/lib/supabase/server";
import { logout } from "../auth/actions";

export default async function DashboardPage() {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  return (
    <div className="min-h-screen">
      <nav className="px-6 md:px-12 py-6 flex items-center justify-between border-b border-sand-dark">
        <div className="font-display text-2xl font-medium tracking-tight text-brown-dark">
          Voya<span className="text-terracotta">.</span>
        </div>
        <form action={logout}>
          <button type="submit" className="btn-ghost text-sm">
            Cerrar sesión
          </button>
        </form>
      </nav>

      <main className="px-6 md:px-12 lg:px-20 py-12 max-w-7xl mx-auto">
        <div className="mb-10">
          <h1 className="font-display text-4xl md:text-5xl font-light text-brown-dark mb-3">
            Hola <span className="italic text-terracotta">✦</span>
          </h1>
          <p className="text-brown-mid font-light">
            Bienvenida a Voya, {user?.email}
          </p>
        </div>

        <div className="card-base text-center py-16">
          <div className="text-6xl mb-6">🌴</div>
          <h2 className="font-display text-2xl font-medium text-brown-dark mb-3">
            Tu dashboard está casi listo
          </h2>
          <p className="text-brown-mid font-light max-w-md mx-auto mb-2">
            Estamos construyendo el espacio donde podrás crear y administrar
            todos tus viajes.
          </p>
          <p className="text-sm text-brown-soft">
            Próximamente: crear viajes, descubrir actividades con AI, calendario
            y presupuesto.
          </p>
        </div>
      </main>
    </div>
  );
}
